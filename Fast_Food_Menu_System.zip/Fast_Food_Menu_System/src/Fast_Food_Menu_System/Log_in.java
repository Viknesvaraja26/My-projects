/* Project Title : Fast Food Menu System
 *        Author : VIKNESVARAJA NAIDU (4193004891)
 *               : SURENDAR RAO (4193004581)
*/

package Fast_Food_Menu_System;

import javax.swing.JOptionPane;//Import swing components of JOptionPane


public class Log_in  {//class Log_in
 // The private instance variables  for class Log_in   
	private String user = "john";
        private String pas  = "abc123";
        
        private String pass;
        private String username;
	public void Login(){
	
       //input username and passwod    
        username = JOptionPane.showInputDialog("Enter the username :");
        pass = JOptionPane.showInputDialog("Enter the password :");
        
        
	/*if else statement is used to continue the program 
         * when correct usermane and password has been entered
         */
		if(username.equals(user) && pass.equals(pas) ){
             
            JOptionPane.showMessageDialog(null, "Log in Successful");
            //when statement is true diplays a dialog box message
        }
        else    
        {
            /*when statement is false displays a dialog box message 
             *and asks the user to re-enter the username and password
             */
            JOptionPane.showMessageDialog(null,"Invalid Login ID!!!\n\nPlease try again");
             Log_in ln = new Log_in();
             ln.Login();
        
        }
     }
        
    //instance method to exit program and re-run the program
public void exit(){
     int yes_no; // Create a class attribute
     
   //input box to input 2 to exit program or choose any other intger to continue
     String no = JOptionPane.showInputDialog("Input 2 to exit or 1 to continue: ");
     yes_no = Integer.parseInt(no);
   
//if statment     
if(yes_no==2){//true statement when user input digit 2
    JOptionPane.showMessageDialog(null,"\n~ ~ ~ THANK YOU. HAVE A NICE DAY!!! ~ ~ ~\n");
    System.exit(0);
   
}else//false statement when user input wrong integer
{
   MainMenu menu = new MainMenu();//inheritance from Class MainMenu
   
   menu.printHeader();//inherit printHeader object
   menu.printMenu();//inherit printMenu object 
   String vv; 
    int nu ;
  do{
        
   MainMenu mainmenu = new MainMenu();
   mainmenu.prompt();      
   //display input box for user to enter 1 to order more
   vv = JOptionPane.showInputDialog("Enter 1 to add on and 0 to exit : ");
    nu = Integer.parseInt(vv);
   
    }while(nu == 1);
    /*after ending the statement 
    *calls objects from class Calculate and class Log_in
    *to use the objects of the respective classes
    */
   Calculate cal = new Calculate();
   cal.calculation();//inheritance of calculation object
   
        
       Log_in out = new Log_in();
       out.exit();//inheritance of the exit object 
}



}

        
}
    

