/* Project Title : Fast Food Menu System
 *        Author : VIKNESVARAJA NAIDU (4193004891)
 *               : SURENDAR RAO (4193004581)
*/

package Fast_Food_Menu_System;

//encapsulation applied using setter and getter mthod

//class FastFood inherited attributes from class MainMenu
public class FastFood extends MainMenu{ 
    //private instance variable for FastFood class
    private String name;
    private double price;
    private double waiting_time;
    //constructor for FastFood instance with name, price and waiting_time
public FastFood(String name, double price, double waiting_time){
   
    //call methods and access constructors from superclass
        super();
 //reuse the variables declared using composition
        this.name = name;
        this.price = price;
        this.waiting_time = waiting_time;
    }
//setter methods and getter methods
    public String getName() {//getter method and return name of the set
        return name;
    }

    public void setName(String name) {//setter method for name of the set
        this.name = name;
    }

    public double getPrice() { // getter method and return price of the set
        return price;
    }

    public void setPrice(double price) {// setter method for price of the set
        this.price = price;
    }
/* getter method for waiting time and return waiting time*/
    public double getWaiting_time() { 
        return waiting_time;
    }
/* setter method for waiting time*/
    public void setWaiting_time(double waiting_time) {
        this.waiting_time = waiting_time;
    }


    }
    
   

