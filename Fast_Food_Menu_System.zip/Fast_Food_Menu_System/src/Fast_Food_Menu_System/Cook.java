/* Project Title : Fast Food Menu System
 *        Author : VIKNESVARAJA NAIDU (4193004891)
 *               : SURENDAR RAO (4193004581)
*/

package Fast_Food_Menu_System;

import java.util.logging.Level;// import log level
import java.util.logging.Logger;// import logger

//class Cook inherited attributes of Thread function
public class Cook extends Thread{ 
    
    FastFood fastfood;//default construtors to use attributes of FastFood class
    Cashier cashier; //default constructors to use attributes of Cashier class 

    
public Cook(FastFood fastfood, Cashier cashier) {//Default Constructor for Cook
    
//call a method defined in the super class and access constructors    
        super();
//default constructors to use FastFood class attributes in Cook class using composition      
        this.fastfood = fastfood;
//default constructors to use Cashier class in Cook class using composition
        this.cashier = cashier;
   
    }
// implement  with try catch method
    /*thread acts as a cook to tell waiting time to prepare the food 
     *as it takes the fastfood object order
     *and prepare the food until the 
     *sleep time for the event which we set is up
     *after its done it nofies the user that order ready
     */
    @Override
    public void run(){
          //set waiting time (millisecond sleep) 
            //(note:1000millisecond = 1 second)
            
            /*thread is sleeping so to break the waiting time we use InterruptedException ex
            *and continue the program
            */
 
        try {  
            Thread.sleep((long) (fastfood.getWaiting_time() * 2000));
        } 
        catch (InterruptedException ex) {
            Logger.getLogger(Cook.class.getName()).log(Level.SEVERE, null, ex);
//to test the code in try to use exception ex then run the logger
            
/*The severe() method of a Logger class used to Log a SEVERE message.
*This method is used to pass SEVERE types logs to all the output handeler objects.
*message is forwarded to he registered output Handler objects.
*/
        }
//call the orderready object from Cashier class
        cashier.orderready(fastfood);        
    }
    
}
