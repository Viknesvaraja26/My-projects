/* Project Title : Fast Food Menu System
 *        Author : VIKNESVARAJA NAIDU (4193004891)
 *               : SURENDAR RAO (4193004581)
*/

package Fast_Food_Menu_System;
import java.time.format.DateTimeFormatter;//Import date time format  
import java.time.LocalDateTime;  //Import curent date and time
import javax.swing.JOptionPane;//Import swing components for JOptionPane

//class MainMenu inherits(access interface methods in) class Cashier
public class MainMenu implements Cashier {
    
    void printHeader() { //class member instance method
        //header to display author and welcome message
JOptionPane.showMessageDialog(null,"\n"
        + "-----------------------------\n"
        + "**Welcome to\n                Fast Food Menu System**\n"
        + "                      -----------------------------\n\n" 
+"Author:\nVIKNESVARAJA NAIDU (4193004891)\nSURENDAR RAO (4193004581)\n");

Log_in lg = new Log_in();     
lg.Login(); 

    }//class member instance method, to display food menu and price
     //notfy the user how to use them
    void printMenu(){
         JOptionPane.showMessageDialog(null,"Please Select a Set:\nSET A:0 SET B:1 SET C:2\n\n"
                 + "SET A >>\n chicken small\n burger\n cola\n PRICE: RM20 \n\n"
                 + "SET B >>\n chicken double\n zinger burger\n pepsi\n PRICE: RM30\n\n"
                 + "SET C >>\n Jumbo Chicken set\n five zinger burger\n two bottle\n PRICE:RM100\n\n");
    
    }
    
    
    
 //private instance variable for cashier name and id     
private String cName;
private int id;

    public void setName(String newName){//Setter method for cashier name
    cName= newName;      
}

public String getName(){//Getter method for cashier name
    return cName;
}

public void setId(int newId){ //Setter method for cashier id
    id= newId;
}

public int getId(){ //Getter method for cashier id
    return id;
}
    
    

// class member instance method and contains name price and preparing time 
public void prompt(){
    //set the array to display order items , price and time
    FastFood SetA = new FastFood ("\nSET A >>\n chicken small\n burger\n cola\n", 20, 5);
    FastFood SetB = new FastFood ("\nSET B >>\n chicken double\n zinger burger\n pepsi\n", 30, 10);
    FastFood SetC = new FastFood ("\nSET C >>\n Jumbo Chicken set\n five zinger burger\n two bottle 7up\n", 100, 15);
    //selection array to select the sets
    FastFood[] Sets = new FastFood[] {SetA, SetB,SetC};
     //displayy order details and input box for user to enter the order of choice
    int select = Integer.parseInt(JOptionPane.showInputDialog(null,
                   "SET A(0) >>\n chicken small\n burger\n cola\n PRICE: RM20 \n\n"
                 + "SET B(1) >>\n chicken double\n zinger burger\n pepsi\n PRICE: RM30\n\n"
                 + "SET C(2) >>\n Jumbo Chicken set\n five zinger burger\n two bottle\n PRICE:RM100\n\n"  
                 + "Please Select a set :"));
    FastFood selection = Sets[select];
    
     //declaration of variables
    double price1;
    int quantity;
    String num;
     //display order details input box to select quantity of food ordered    
        num = JOptionPane.showInputDialog("Enter the quantity for:\n"
                                           +selection.getName()+"\n"
                                           +"RM"+selection.getPrice()+"0");
        quantity = Integer.parseInt(num);//change string to integer
        //calculation off total price of single order
        price1 = selection.getPrice()*quantity; 
        
        System.out.println("\nTotal price of "+ selection.getName()  + "is RM: "+ price1+"0"  );
    
//inheriting object from Cook class 
    Cook cook = new Cook(selection, this);
    cook.start();//excecute the thread method in class Cook
          
    }

 //use polymophism override the orderready mehtod of parent class Cashier 
@Override
    public void orderready(FastFood fastfood) {
        /*notify the user that the order is ready
        * display cashier name and id
        * display current date and time
        */
       MainMenu m = new MainMenu();
       //set current date and time format
       DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd  HH:mm:ss");  
       LocalDateTime now = LocalDateTime.now();//get current date and time   
        m.setName("Chetah");//set chashier name
        m.setId(42412);//set cashier id
     //display cashier name and id
     //display choosen set name and details
     //display thank you message
        JOptionPane.showMessageDialog(null,dtf.format(now)
                + "\nCashier Name : " 
                + m.getName()
                + "\nCashier Id   : " 
                + m.getId()
                + fastfood.getName()
                +"\nTHANK YOU FOR WAITING.\n YOUR ORDER IS READY!");
         
    }
    
    
    public static void main(String[] args){//main method
    //declaration of variables
    String vv; 
    int nu ;
    
    //inheritance to call objects in MainMenu
   MainMenu menu = new MainMenu();
   menu.printHeader();
   menu.printMenu();
   //loop used to excetue the  statements repeatedly
   //to enter multiple choice sets of order
    do{
        
   MainMenu mainmenu = new MainMenu();
   mainmenu.prompt();      
   //displa input box for user to enter 1 to order more
   vv = JOptionPane.showInputDialog("Enter 1 to add on and 0 to exit : ");
    nu = Integer.parseInt(vv);
   
    }while(nu == 1);
    /*after ending the statement 
    *calls objects from class Calculate and class Log_in
    *to use the objects of the respective classes
    */
   Calculate cal = new Calculate();
   cal.calculation();//inheritance of calculation object
   
        
       Log_in out = new Log_in();
       out.exit();//inheritance of the exit object 
}
    
    

}                         