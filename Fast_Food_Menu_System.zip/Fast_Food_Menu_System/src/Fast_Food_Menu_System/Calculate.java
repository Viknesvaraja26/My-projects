/* Project Title : Fast Food Menu System
 *        Author : VIKNESVARAJA NAIDU (4193004891)
 *               : SURENDAR RAO (4193004581)
*/

package Fast_Food_Menu_System;

import javax.swing.JOptionPane;//Import swing components of JOptionPane

public class Calculate {//class Calculate

    
    
private double price1,amount, balance, total;//private instance variable for calculation class
 private String num1,num2;//private instance variable for calculation class
 
    public void calculation(){//Constructor for calculation

         num1 = JOptionPane.showInputDialog("Enter Price of the set ordered: RM ");
                  
         price1 = Integer.parseInt( num1 );//convert num1 to double
         /*input total price*/
         
         total = price1;
         JOptionPane.showMessageDialog(null, "Your total is: RM" + total+"0\n");
        //output of price1 which got from variable(total)
        
         num2 = JOptionPane.showInputDialog("Enter Amount paid: RM ");
         /*input amount customer gave*/
         amount = Integer.parseInt( num2 );//conver num2 to from string to double
        
         
         /*if Statement with calculation of total price*/
        if(price1<=amount){
            
            balance = amount-total;
            JOptionPane.showMessageDialog(null, "Your balance is: RM " + balance+"0" + "\nOder Ready.\n\n");
            
        }else
        {
           JOptionPane.showMessageDialog(null,"Invalid amount, Please try again!!!");
            
            Calculate cal = new Calculate();
            cal.calculation();
            
        }            
         
    }

}
