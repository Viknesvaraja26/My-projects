/* Project Title : Fast Food Menu System
 *        Author : VIKNESVARAJA NAIDU (4193004891)
 *               : SURENDAR RAO (4193004581)
*/

package Fast_Food_Menu_System;

//abstraction is used so that objects cannot be created using class Cashier
abstract public interface Cashier {    //interface Cashier is an event listener
    
/*notifies all class that the food has been prepared 
 *and return the FastFood object
*/ 
    public void orderready(FastFood fastfood);
    
}

