<?php
	$conn = new mysqli('localhost', 'root', '', 'vdatabase');
	if(!$conn){
		die("Fatal Error: Connection Error!");
	}

?>
