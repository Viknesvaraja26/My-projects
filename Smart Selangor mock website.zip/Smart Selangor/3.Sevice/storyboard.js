// JavaScript Document
	function cal() 

		{	
			//input
			var a = document.getElementById('age')
			var b = document.getElementById('pressure')
			var c = document.getElementById('chol')
			var d =document.getElementById('hdl')
			var e = document.getElementById('medi')
			var f = document.getElementById('cigi')
			var g = document.getElementById('diab')
			
			//conversion
			var a = parseFloat(a.value)
			var b = parseFloat(b.value)
			var c = parseFloat(c.value)
			var d = parseFloat(d.value)
			var e = parseFloat(e.value);
			var f = parseFloat(f.value);
			var g = parseFloat(g.value);
        
			var risk1 =(Math.log(a)*3.06117)+(Math.log(c)*1.12370)-(Math.log(d)*0.93263)+(Math.log(b)*e)+f+(g-23.9802)
			var risk2 =100*((1-0.88936)*(Math.exp(risk1)))
				
		    alert("Risk factors are " + risk2);
			document.getElementById("risk3").value = risk2;
			
		}

function calcBMI()
{
var w = document.getElementById("w").value;
var h = document.getElementById("h").value;

var bmi = w/(h/100*h/100);

document.getElementById("bmi").value = bmi;
}

function calcBMR()
{
	var weight = document.getElementById("weight").value;
	//var weight = document.getElementById("weight").value;
	
    var height = document.getElementById("height").value
	//var height = document.getElementById("height").value
	
	var age = document.getElementById("age1").value
	//var age = document.getElementById("age").value
	
	var bmr = 66.47 + (13.75* weight) + (5.003* height) - (6.755* age);
	
	document.bmrform.bmr.value = Math.round(bmr*100)/100.0;
	//document.getElementById("bmr").value = bmr;
}