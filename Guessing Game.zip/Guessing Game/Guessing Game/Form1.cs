﻿using System;
using System.Windows.Forms;

namespace Guessing_Game
{
    public partial class guess : Form
    {
        int SecretNumber;
        int attempt;
        int count;
        public guess()
        {
            InitializeComponent();
        }

        private void guess_Load(object sender, EventArgs e)
        {
            attempt = 10;
            count = 0;
            SecretNumber = generateSecretNumber();
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void input_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(input.Text);



            if (input.Text.Trim() == string.Empty)
            {
                MessageBox.Show(" Error!!!. Please enter something in the textbox");
                return;
            }

            int guess = 0;
            guess = Convert.ToInt32(input.Text);

            attempt--;
            label2.Text = "Guess Attempt: " + attempt;


            if (guess > 500 || guess <= 0)
            {
                MessageBox.Show("Error!! guess cannot be more than 500 and less than 1 !!"+"\nPlease Try again...");
            }
            else
            {
                if (guess == SecretNumber && attempt == 9)
                {
                    MessageBox.Show("You managed to guess the number in ONE try only");
                    MessageBox.Show("WOW, YOU ARE A GENIUS.");

                    button1.Visible = false;
                    if (MessageBox.Show("Do you want to play again?", "Start a new  game", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        Application.Restart();
                    }
                    else
                    {
                        MessageBox.Show("Thank You");
                        Application.Exit();
                    }
                }
                else if (guess == SecretNumber && attempt >= 7 && attempt <= 10)
                {
                    MessageBox.Show("WOW, YOU ARE A GENIUS.");

                    button1.Visible = false;
                    if (MessageBox.Show("Do you want to play again?", "Start a new  game", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        Application.Restart();
                    }
                    else
                    {
                        MessageBox.Show("Thank You");
                        Application.Exit();
                    }
                }
                else if (guess == SecretNumber && attempt >= 4 && attempt <= 6)
                {
                    MessageBox.Show("GREAT, YOU ARE CLEVER.");

                    button1.Visible = false;
                    if (MessageBox.Show("Do you want to play again?", "Start a new  game", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        Application.Restart();
                    }
                    else
                    {
                        MessageBox.Show("Thank You");
                        Application.Exit();
                    }
                }
                else if (guess == SecretNumber && attempt >= 1 && attempt <= 3)
                {
                    MessageBox.Show("GOOD, YOU MADE IT!");

                    button1.Visible = false;
                    if (MessageBox.Show("Do you want to play again?", "Start a new  game", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        Application.Restart();
                    }
                    else
                    {
                        MessageBox.Show("Thank You");
                        Application.Exit();
                    }
                }

                else if (guess == SecretNumber)
                {
                    MessageBox.Show("You managed to guess the number in " + attempt + " trys.");
                    MessageBox.Show("You Won");

                    button1.Visible = false;
                    if (MessageBox.Show("Do you want to play again?", "Start a new  game", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        Application.Restart();
                    }
                    else
                    {
                        MessageBox.Show("Thank You");
                        Application.Exit();
                    }

                }

                else if (attempt == count)
                {
                    MessageBox.Show("Sorry, You missed it! Game Lost");
                    MessageBox.Show("The answer is " + SecretNumber);
                    if (MessageBox.Show("Do you want to play again?", "Start a new game", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        Application.Restart();
                    }
                    else
                    {
                        MessageBox.Show("Thank You");
                        Application.Exit();
                    }
                }
                else if (guess < SecretNumber)
                {
                    MessageBox.Show("Guessed number is too low!");

                }
                else if (guess > SecretNumber)
                {
                    MessageBox.Show("Guessed number is too high!");
                }
                else
                {
                    MessageBox.Show("Error!!..Only numbers are allowed");
                }
            }
        }
   
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private int generateSecretNumber()
        {
            Random number = new Random();
            int SecretNumber = number.Next(1,500);

            return SecretNumber;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void clear_Click(object sender, EventArgs e)
        {
            input.Clear();       
            listBox1.Items.Clear();
        }

        private void input_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
            }
        }
    }
}
