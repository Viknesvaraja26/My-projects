execute:-
travel(Holiday),
write('You should go to '),
write(Holiday),
write('for your holiday.'),
nl,
write('Thank you!!!'),
write('Have a nice day.'),
undo.

/*Travel place name convert to code*/
travel('LANGKAWI ') :- langkawi, !.    /*rule 1*/
travel('PINANG ') :- pinang, !.       /*rule 2*/
travel('MALACCA ') :- malacca, !.    /*rule 3*/
travel('Sorry. It is not found. '). /*rule not found*/

/*Rule 1*/
langkawi:-
rule('holiday is 3 days'),
rule('budget RM500'),
nl.

/*Rule 2*/
pinang :-
rule('holiday is 5 days'),
rule('budget RM1000'),
nl.

/*Rule 3*/
malacca :-
rule('holiday is 8 days'),
rule('budget is RM2000'),
nl.


/*Asking questions to user*/
prompt(Question) :-
write('Is your '),
write(Question),
write('? '),
read(Response),
nl,
( (Response == yes ; Response == y) -> assert(yes(Question)) ; assert(no(Question)), fail).
:- dynamic yes/1,no/1.

/*rule statement*/
rule(R) :-(yes(R)->true ;(no(R)->fail ;prompt(R))).

undo :- retract(yes(_)),fail.
undo :- retract(no(_)),fail.
undo.
